var data = [
  {
    'title' : 'Politics',
    'percentage' : 10.0,
    'color': '#62dcff'
  },
  {
    'title' : 'Sports',
    'percentage' : 30.0,
    'color': '#62dcff'
  },
  {
    'title' : 'World',
    'percentage' : 40.0,
    'color': '#62dcff'
  },
  {
    'title' : 'Art',
    'percentage' : 20.0,
    'color': '#62dcff'
  }
];
